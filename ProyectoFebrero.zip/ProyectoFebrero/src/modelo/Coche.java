package modelo;

import java.util.ArrayList;

public class Coche {
    private String matricula;
    private String marca;
    private String modelo;
    private int año;
    private ArrayList<Pieza> piezas;
    private void agregarPiezasPredeterminadas() {
        piezas.add(new Pieza(1, "Motor", "Mecánica", 1500.0, "Nuevo"));
        piezas.add(new Pieza(2, "Rueda Delantera Izquierda", "Neumático", 200.0, "Usado"));
        piezas.add(new Pieza(3, "Rueda Delantera Derecha", "Neumático", 200.0, "Usado"));
        piezas.add(new Pieza(4, "Frenos", "Seguridad", 300.0, "Nuevo"));
        piezas.add(new Pieza(5, "Batería", "Eléctrico", 180.0, "Nuevo"));
    }
    public Coche(String matricula, String marca, String modelo, int año) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.año =año;
        this.piezas = new ArrayList<>();
        agregarPiezasPredeterminadas();
    }



    public String getMatricula() {
        return matricula;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getAño() {
        return año;
    }

    public ArrayList<Pieza> getPiezas() {
        return piezas;
    }

    public void agregarPieza(Pieza pieza) {
        this.piezas.add(pieza);
    }

    @Override
    public String toString() {
        return "Coche{" +
                "matricula=" + matricula +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", año=" + año +
                ", piezas=" + piezas +
                '}';
    }

    public void setMarca(String marca) {
this.marca = marca;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public void setAño(int año) {
        this.año = año;
    }


}

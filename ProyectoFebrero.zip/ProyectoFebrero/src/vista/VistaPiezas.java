package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Pieza;
import java.util.ArrayList;
import java.io.*;

public class VistaPiezas extends JFrame {
    private JTextField txtNombre;
    private JTextField txtTipo;
    private JTextField txtPrecio;
    private JComboBox<String> cmbEstado;
    private JButton btnRegistrar;
    private JTextArea txtAreaPiezas;
    private ArrayList<Pieza> listaPiezas;
    private static final String FILE_NAME = "piezas.txt";

    public VistaPiezas() {
        setTitle("Registrar Nueva Pieza");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        listaPiezas = new ArrayList<>();

        txtNombre = new JTextField(15);
        txtTipo = new JTextField(15);
        txtPrecio = new JTextField(15);
        cmbEstado = new JComboBox<>(new String[]{"Nuevo", "Usado", "Defectuoso"});
        btnRegistrar = new JButton("Registrar Pieza");
        txtAreaPiezas = new JTextArea(10, 30);
        txtAreaPiezas.setEditable(false);

        add(new JLabel("Nombre:"));
        add(txtNombre);
        add(new JLabel("Tipo:"));
        add(txtTipo);
        add(new JLabel("Precio:"));
        add(txtPrecio);
        add(new JLabel("Estado:"));
        add(cmbEstado);
        add(btnRegistrar);
        add(new JScrollPane(txtAreaPiezas));

        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarPieza();
            }
        });

        cargarPiezasDesdeArchivo();
    }

    private void registrarPieza() {
        try {
            String nombre = txtNombre.getText();
            String tipo = txtTipo.getText();
            double precio = Double.parseDouble(txtPrecio.getText());
            String estado = (String) cmbEstado.getSelectedItem();

            Pieza nuevaPieza = new Pieza(listaPiezas.size() + 1, nombre, tipo, precio, estado);
            listaPiezas.add(nuevaPieza);
            guardarPiezaEnArchivo(nuevaPieza);

            txtAreaPiezas.append(formatoPieza(nuevaPieza) + "\n");

            txtNombre.setText("");
            txtTipo.setText("");
            txtPrecio.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese un precio válido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarPiezaEnArchivo(Pieza pieza) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(pieza.getId() + "," + pieza.getNombre() + "," + pieza.getTipo() + "," + pieza.getPrecio() + "," + pieza.getEstado());
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar la pieza", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarPiezasDesdeArchivo() {
        if (txtAreaPiezas == null) {
            return; // Evita el error si txtAreaPiezas aún no está inicializado
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    Pieza pieza = new Pieza(Integer.parseInt(parts[0]), parts[1], parts[2], Double.parseDouble(parts[3]), parts[4]);
                    listaPiezas.add(pieza);
                    txtAreaPiezas.append(formatoPieza(pieza) + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("No se pudo cargar el archivo de piezas.");
        }
    }

    private String formatoPieza(Pieza pieza) {
        return "ID: " + pieza.getId() + " | Nombre: " + pieza.getNombre() + " | Tipo: " + pieza.getTipo() +
                " | Precio: $" + pieza.getPrecio() + " | Estado: " + pieza.getEstado();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VistaPiezas().setVisible(true));
    }
}

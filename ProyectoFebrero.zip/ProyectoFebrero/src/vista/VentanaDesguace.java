package vista;

import controlador.CocheLista;
import modelo.Coche;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentanaDesguace extends JFrame {
    private CocheLista desguace;
    private DefaultTableModel modeloTabla;
    private JTable tabla;

    public VentanaDesguace() {
        desguace = new CocheLista();

        //Configuracion de la ventana
        setTitle("🚘 Desguace de Coches");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        //tabla que muestra coches
        String[] columnas = {"Matrícula", "Marca", "Modelo", "Año"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tabla = new JTable(modeloTabla);
        actualizarTabla();
        add(new JScrollPane(tabla), BorderLayout.CENTER);




        // 🔹 Panel con botones
        JPanel panelBotones = new JPanel();

        JButton btnAgregar = new JButton("➕ Agregar Coche");
        JButton btnEliminar = new JButton("🗑️ Eliminar Coche");
        JButton btnActualizar = new JButton("🔄 Actualizar Lista");
        JButton btnEditar = new JButton("✏️ Editar Coche");
        JButton btnVerPiezas = new JButton("🔧 Ver Piezas");
        JButton btnHistorialVentas = new JButton("📜 Historial de Ventas");


        panelBotones.add(btnHistorialVentas);
        panelBotones.add(btnVerPiezas);
        panelBotones.add(btnEditar);
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnActualizar);
        add(panelBotones, BorderLayout.SOUTH);


        // 🔹 Eventos de los botones
        btnAgregar.addActionListener(e -> añadirCoche());
        btnEliminar.addActionListener(e -> eliminarCoche());
        btnActualizar.addActionListener(e -> actualizarTabla());
        btnEditar.addActionListener(e -> editarCoche());
        btnVerPiezas.addActionListener(e -> verPiezas());


    }



    // 📌 Método para agregar un coche
    private void añadirCoche() {
        String matricula = JOptionPane.showInputDialog(this, "Ingrese Matrícula:");
        String marca = JOptionPane.showInputDialog(this, "Ingrese Marca:");
        String modelo = JOptionPane.showInputDialog(this, "Ingrese Modelo:");
        String añoTexto = JOptionPane.showInputDialog(this, "Ingrese Año:");

        if (matricula != null && marca != null && modelo != null && añoTexto != null) {
            try {
                int año = Integer.parseInt(añoTexto);
                desguace.añadirCoche(new Coche(matricula, marca, modelo, año));
                actualizarTabla();
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "❌ Año inválido. Debe ser un número.");
            }
        }
    }

    // 📌 Método para eliminar un coche por matrícula
    private void eliminarCoche() {
        String matricula = JOptionPane.showInputDialog(this, "Ingrese la Matrícula a eliminar:");
        if (matricula != null) {
            desguace.eliminarCoche(matricula);
            actualizarTabla();
        }
    }
    //Metodo para editar un coche
    private void editarCoche() {
        int filaSeleccionada = tabla.getSelectedRow(); // Obtener la fila seleccionada

        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "❌ Seleccione un coche para editar.");
            return;
        }

        // Obtener datos actuales
        String matriculaActual = (String) modeloTabla.getValueAt(filaSeleccionada, 0);
        String marcaActual = (String) modeloTabla.getValueAt(filaSeleccionada, 1);
        String modeloActual = (String) modeloTabla.getValueAt(filaSeleccionada, 2);
        int añoActual = (int) modeloTabla.getValueAt(filaSeleccionada, 3);

        // Pedir nuevos datos
        String nuevaMarca = JOptionPane.showInputDialog(this, "Nueva Marca:", marcaActual);
        String nuevoModelo = JOptionPane.showInputDialog(this, "Nuevo Modelo:", modeloActual);
        String nuevoAñoTexto = JOptionPane.showInputDialog(this, "Nuevo Año:", añoActual);

        // Validar entrada
        if (nuevaMarca != null && nuevoModelo != null && nuevoAñoTexto != null) {
            try {
                int nuevoAño = Integer.parseInt(nuevoAñoTexto);
                desguace.editarCoche(matriculaActual, nuevaMarca, nuevoModelo, nuevoAño);
                actualizarTabla(); // Refrescar la tabla
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "❌ Año inválido. Debe ser un número.");
            }
        }
    }





    // 📌 Método para actualizar la tabla con los coches
    private void actualizarTabla() {
        modeloTabla.setRowCount(0); // Limpiar tabla
        for (Coche coche : desguace.obtenerListaCoches()) {
            modeloTabla.addRow(new Object[]{coche.getMatricula(), coche.getMarca(), coche.getModelo(), coche.getAño()});
        }
    }

    // 📌 Método para iniciar la interfaz
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VentanaDesguace ventana = new VentanaDesguace();
            ventana.setVisible(true);
        });
    }



    //Metodo para ver piezas
    private void verPiezas() {
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "❌ Seleccione un coche para ver sus piezas.");
            return;
        }

        String matricula = (String) modeloTabla.getValueAt(filaSeleccionada, 0);
        for (Coche coche : desguace.obtenerListaCoches()) {
            if (coche.getMatricula().equals(matricula)) {
                VistaPiezas ventanaPiezas = new VistaPiezas();
                ventanaPiezas.setVisible(true);
                return;
            }
        }
    }

}








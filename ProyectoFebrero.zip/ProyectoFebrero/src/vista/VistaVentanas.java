package vista;

import modelo.Coche;
import modelo.Pieza;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class VistaVentanas extends JFrame {
    private DefaultListModel<String> modeloListaCoches;
    private JList<String> listaCoches;
    private JButton btnAgregarCoche, btnVerPiezas;
    private List<Coche> coches;

    public VistaVentanas() {
        setTitle("🏚️ Desguace de Coches");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        coches = new ArrayList<>();

        // Modelo de lista para mostrar coches
        modeloListaCoches = new DefaultListModel<>();
        listaCoches = new JList<>(modeloListaCoches);
        JScrollPane scrollPane = new JScrollPane(listaCoches);
        add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel panelBotones = new JPanel();
        btnAgregarCoche = new JButton("Agregar Coche");
        btnVerPiezas = new JButton("Ver Piezas");

        panelBotones.add(btnAgregarCoche);
        panelBotones.add(btnVerPiezas);
        add(panelBotones, BorderLayout.SOUTH);

        // Evento para agregar un coche
        btnAgregarCoche.addActionListener(e -> agregarCoche());

        // Evento para ver las piezas del coche seleccionado
        btnVerPiezas.addActionListener(e -> verPiezas());
    }

    // Método para agregar un coche
    private void agregarCoche() {
        String matricula = JOptionPane.showInputDialog("Ingrese la matrícula:");
        if (matricula == null || matricula.trim().isEmpty()) return;

        String marca = JOptionPane.showInputDialog("Ingrese la marca:");
        if (marca == null || marca.trim().isEmpty()) return;

        String modelo = JOptionPane.showInputDialog("Ingrese el modelo:");
        if (modelo == null || modelo.trim().isEmpty()) return;

        int año;
        try {
            año = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año:"));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Año inválido.");
            return;
        }


    }

    // Método para ver las piezas del coche seleccionado
    private void verPiezas() {
        int index = listaCoches.getSelectedIndex();  // Obtener coche seleccionado
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un coche.");
            return;
        }








        // Obtener el coche seleccionado
        Coche cocheSeleccionado = coches.get(index);

        // Crear ventana de piezas
        VistaPiezas vistaPiezas = new VistaPiezas();
        vistaPiezas.setVisible(true);  // Mostrar la ventana de piezas
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VistaVentanas().setVisible(true));
    }
}

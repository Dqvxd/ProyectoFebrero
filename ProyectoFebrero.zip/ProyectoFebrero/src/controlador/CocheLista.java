package controlador;
import modelo.Coche;
import modelo.Pieza;
import java.io.*;
import java.util.ArrayList;

public class CocheLista {
    private ArrayList<Coche> coches = new ArrayList<>();
    private static final String ARCHIVO = "coches.txt";

    public CocheLista() {
        cargarDesdeArchivo();
    }

    public void añadirCoche(Coche coche) {
        coches.add(coche);
        System.out.println("🚗 Coche añadido: " + coche);
        guardarEnArchivo();
    }

    public void listarCoche() {
        if (coches.isEmpty()) {
            System.out.println("No hay coches en el desguace.");
        } else {
            for (Coche c : coches) {
                System.out.println(c);
            }
        }
    }

    public void eliminarCoche(String matricula) {
        coches.removeIf(c -> c.getMatricula().equals(matricula));
        System.out.println("🗑 Coche eliminado con matrícula: " + matricula);
        guardarEnArchivo();
    }

    private void guardarEnArchivo() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO))) {
            for (Coche c : coches) {
                bw.write(c.getMatricula() + "," + c.getMarca() + "," + c.getModelo() + "," + c.getAño());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("❌ Error al guardar en el archivo: " + e.getMessage());
        }
    }
    private void cargarDesdeArchivo() {
        coches.clear(); // Limpiar la lista antes de cargar
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 4) {
                    String matricula = datos[0];
                    String marca = datos[1];
                    String modelo = datos[2];
                    int año = Integer.parseInt(datos[3]);
                    coches.add(new Coche(matricula, marca, modelo, año));
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("⚠️ Archivo no encontrado. Se creará uno nuevo al guardar.");
        } catch (IOException e) {
            System.out.println("❌ Error al leer el archivo: " + e.getMessage());
        }
    }



    //Metodo para obtener la lista de coches al hacer la ventanadesguace
    public ArrayList<Coche> obtenerListaCoches() {
        return coches;
    }

//metodo para editar coche
    public void editarCoche(String matricula, String nuevaMarca, String nuevoModelo, int nuevoAño) {
        for (Coche coche : coches) {
            if (coche.getMatricula().equals(matricula)) {
                coche.setMarca(nuevaMarca);
                coche.setModelo(nuevoModelo);
                coche.setAño(nuevoAño);
                return;
            }
        }
    }

    public Coche buscarCochePorId(String matricula) {
        for (Coche coche : coches) {
            if (coche.getMatricula() == matricula) {
                return coche;
            }
        }
        System.out.println("❌ Coche con ID " + matricula + " no encontrado.");
        return null;
    }




    public void agregarPiezaACoche(String idCoche, Pieza pieza) {
        Coche coche = buscarCochePorId(idCoche);
        if (coche != null) {
            coche.agregarPieza(pieza);
            System.out.println("✅ Pieza añadida al coche con ID " + idCoche);
            guardarEnArchivo();
        }
    }

    public ArrayList<Coche> getCoches() {
        return coches;
    }
}



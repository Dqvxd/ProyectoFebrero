package main;
import modelo.Coche;
import controlador.CocheLista;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        CocheLista desguace = new CocheLista();



        while (true) {
            System.out.println("\n🚘 Desguace de Coches - Menú");
            System.out.println("1. Agregar Coche");
            System.out.println("2. Listar Coches");
            System.out.println("3. Eliminar Coche");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Matrícula: ");
                    String matricula = scanner.nextLine();
                    System.out.print("Marca: ");
                    String marca = scanner.nextLine();
                    System.out.print("Modelo: ");
                    String modelo = scanner.nextLine();
                    System.out.print("Año: ");
                    int año = scanner.nextInt();
                    desguace.añadirCoche (new Coche(matricula, modelo, marca, año));
                    break;
                case 2:
                    desguace.listarCoche();
                    break;
                case 3:
                    System.out.print("Matrícula del coche a eliminar: ");
                    String mat = scanner.nextLine();
                    desguace.eliminarCoche(mat);
                    break;
                case 4:
                    System.out.println("👋 ¡Hasta luego!");
                    scanner.close();
                    return;
                default:
                    System.out.println("❌ Opción no válida.");
            }
        }
    }
}

